clear all

filename=sprintf('../../data/feedback_kp/data_Dkp15_Drl15_memThick2/gradient/cell_rdme_Lmem_gradSteep_t500_1_c1b_0.5e-5_c2b_1.0e-5_c3b_1.0e-3_c0a_4.0e-3_c4_7.0e-3_c5_5.0e-3_c6_4.0e-5_c7_4.0e-5_Dk_5.0e-12_Dkp_5.0e-15_Dr_5.0e-12_Drl_5.0e-15.lm');
replicate=52;
cutoffDistance=3;
begt=10;
endt=70;

for ts=21
% ts=10;
ts
[M]=cluster_Chaining2(filename,replicate,ts,cutoffDistance)
% [M,centerpts]=cluster_RLalg(filename,replicate,ts,cutoffDistance)
[idx]=ind2sub(size(M(:,4),1),find(M(:,4)>0))
for i=1:size(idx,1)
    M2a(i)=M(idx(i),1);
    M2b(i)=M(idx(i),2);
    M2c(i)=M(idx(i),3);
    M2d(i)=M(idx(i),4);
end
% M2d
maxt(ts)=max(M2d);
ctr=25;
% [theta phi rho]=cart2sph(M(:,1)-ctr,M(:,2)-ctr,M(:,3)-ctr);
[theta phi rho]=cart2sph(M2a-ctr,M2b-ctr,M2c-ctr);
th(1:size(theta,2),ts)=theta(1,:);
ph(1:size(phi,2),ts)=phi(1,:);
rh(1:size(rho,2),ts)=rho(1,:);
clusterCounts(1:size(theta,2),ts)=M2d(1,:);
% clusterCounts(1:size(theta),ts)=theta(:,1);
% clearvars M;
end
% figur

% plot(1:20,th(5,1:20))
% scatter(th,ts,'filled'),colorbar
% image(clusterCounts*20)
for a=[1:size(clusterCounts,1)]
    for b=1:size(clusterCounts,2)
        theta1(a+(b-1)*size(clusterCounts,1))=th(a,b);
        phi1(a+(b-1)*size(clusterCounts,1))=ph(a,b);
        ts1(a+(b-1)*size(clusterCounts,1))=b;
        counts(a+(b-1)*size(clusterCounts,1))=clusterCounts(a,b);
    end
end
% figure
% subplot(2,1,1)
% scatter(theta1,ts1,100,counts,'.'),colorbar
% xlabel('theta','FontWeight','bold','FontSize',12)
% ylabel('time','FontWeight','bold','FontSize',12)
% % axes([-3.5 3.5 20 70])
% subplot(2,1,2)
% % plot(1:size(clusterCounts,2),sum(clusterCounts,1))
% % figure
% % subplot(2,1,1)
% scatter(phi1,ts1,100,counts,'.'),colorbar
% xlabel('phi','FontWeight','bold','FontSize',12)
% ylabel('time','FontWeight','bold','FontSize',12)
% axes([-0.8 0.8 20 70])
% hist(maxt);
% subplot(2,1,2)
% plot(1:size(clusterCounts,2),sum(clusterCounts,1))
        
% figure
%  scatter(theta1,ts1,'filled')
scatter(theta,M2c,200,M2d,'.'),colorbar
        
        
        
        
        
        